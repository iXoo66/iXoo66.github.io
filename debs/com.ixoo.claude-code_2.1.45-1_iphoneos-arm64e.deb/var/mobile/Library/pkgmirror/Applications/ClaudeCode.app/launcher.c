// Minimal Claude Code iOS Launcher
// Compiles to a Mach-O binary that launches NewTerm with Claude Code

#include <stdlib.h>
#include <unistd.h>
#include <spawn.h>
#include <string.h>

extern char **environ;

int main(int argc, char *argv[]) {
    // Try to open NewTerm3 with claude command via URL scheme
    char *args[] = {"/var/jb/usr/bin/uiopen", "newterm3://run?command=/var/jb/usr/local/bin/claude", NULL};

    pid_t pid;
    int status = posix_spawn(&pid, args[0], NULL, NULL, args, environ);

    if (status != 0) {
        // Fallback: try NewTerm2
        args[1] = "newterm://run?command=/var/jb/usr/local/bin/claude";
        status = posix_spawn(&pid, args[0], NULL, NULL, args, environ);
    }

    if (status != 0) {
        // Last fallback: just open NewTerm
        args[1] = "newterm3://";
        posix_spawn(&pid, args[0], NULL, NULL, args, environ);
    }

    return 0;
}
